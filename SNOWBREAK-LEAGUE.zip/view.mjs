export class SnowView{
 constructor(canvas){this.T=THREE;const T=THREE;this.renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));this.renderer.outputEncoding=T.sRGBEncoding;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=.96;this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.scene=new T.Scene();this.scene.background=new T.Color('#a4dded');this.scene.fog=new T.Fog('#a4dded',42,105);this.camera=new T.PerspectiveCamera(53,1,.1,160);this.camera.position.set(0,20,27);this.geo=new T.BoxGeometry(1,1,1);this.materials={};this.batches=new Map();this.props=new T.Group();this.scene.add(this.props);this.scene.add(new T.HemisphereLight(0xbfe8ff,0x3d506c,.48));let sun=new T.DirectionalLight(0xffe9cb,1.15);sun.position.set(-14,22,9);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-21,right:21,top:21,bottom:-21,near:1,far:90});sun.shadow.normalBias=.035;this.scene.add(sun);this.sun=sun;let rim=new T.DirectionalLight(0xa8dcff,.26);rim.position.set(10,8,-12);this.scene.add(rim);this.staticWorld();this.details();this.refinedScenery();this.flush();this.actors=[0x00a0b9,0xe72d46,0x8655c4,0xe59b10].map((c,i)=>this.actor(c,i));this.walls=[];this.ballMeshes=[];this.fx=[];this.fxGeo=new T.BoxGeometry(.15,.15,.15);this.focus=new T.Mesh(new T.RingGeometry(.67,.76,4),new T.MeshBasicMaterial({color:0xffc94d,side:T.DoubleSide,transparent:true,opacity:.9}));this.focus.rotation.x=-Math.PI/2;this.scene.add(this.focus);this.gift=new T.Group();this.box(this.gift,0,0,0,.6,.6,.6,0xffd14f);this.box(this.gift,0,.01,0,.12,.66,.66,0xff6b73);this.box(this.gift,0,.01,0,.66,.66,.12,0xff6b73);this.scene.add(this.gift);this.snow=new T.InstancedMesh(this.geo,this.mat(0xffffff),100);this.snow.instanceMatrix.setUsage(T.DynamicDrawUsage);this.scene.add(this.snow);this.dummy=new T.Object3D();this.shake=0;this.level=-1;this.camTarget=new T.Vector3();this.makeFilmProps();}
 mat(color,kind='plain'){
 const key=color+'-'+kind;if(this.materials[key])return this.materials[key];const T=THREE;
 const options={color,roughness:kind==='glass'?.22:kind==='leather'?.68:.91,metalness:kind==='glass'?.32:0};
 if(!['plain','glass'].includes(kind)){
 let c=document.createElement('canvas');c.width=c.height=32;let x=c.getContext('2d'),seed=73;const rand=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
 x.fillStyle='#e8e8e8';x.fillRect(0,0,32,32);
 if(kind==='wood'){for(let y=0;y<32;y+=8){x.fillStyle=y%16?'#d4d4d4':'#ededed';x.fillRect(0,y,32,8);x.fillStyle='#a6a6a6';x.fillRect(0,y+7,32,1);for(let j=0;j<4;j++){x.fillStyle=j%2?'#bcbcbc':'#fafafa';x.fillRect(Math.floor(rand()*24),y+1+Math.floor(rand()*5),5+Math.floor(rand()*7),1);}}}
 else if(kind==='brick'){for(let y=0;y<32;y+=8)for(let xx=-8;xx<32;xx+=16){let dx=xx+(y%16?8:0);x.fillStyle=['#dbdbdb','#e8e8e8','#c9c9c9'][(y/8+xx/16+4|0)%3];x.fillRect(dx+1,y+1,15,7);x.fillStyle='#f8f8f8';x.fillRect(dx+1,y+1,14,1);x.fillStyle='#aaaaaa';x.fillRect(dx,y,1,8);x.fillRect(dx,y+7,16,1);}}
 else if(kind==='fabric'){x.fillStyle='#dedede';x.fillRect(0,0,32,32);for(let yy=0;yy<32;yy+=4)for(let xx=0;xx<32;xx+=4){x.fillStyle='#eeeeee';x.fillRect(xx,yy,2,2);x.fillStyle='#c9c9c9';x.fillRect(xx+2,yy+2,2,1);}}
 else if(kind==='snow'){for(let i=0;i<16;i++){let v=224+Math.floor(rand()*19);x.fillStyle='rgb('+v+','+v+','+v+')';let xx=Math.floor(rand()*8)*4,yy=Math.floor(rand()*8)*4;x.fillRect(xx,yy,6,3);x.fillRect(xx+2,yy+3,4,2);}}
 else {for(let i=0;i<18;i++){x.fillStyle=i%2?'#d3d3d3':'#ececec';x.fillRect(Math.floor(rand()*16)*2,Math.floor(rand()*16)*2,3,2);}}
 let tex=new T.CanvasTexture(c);tex.magFilter=T.NearestFilter;tex.minFilter=T.NearestFilter;tex.encoding=T.sRGBEncoding;options.map=tex;
 }return this.materials[key]=new T.MeshStandardMaterial(options);
 }
 box(group,x,y,z,w,h,d,col,kind='plain'){let m=new THREE.Mesh(this.geo,this.mat(col,kind));m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;}
 tile(x,y,z,w,h,d,col,kind='plain'){let mat=this.mat(col,kind);if(!this.batches.has(mat))this.batches.set(mat,[]);this.batches.get(mat).push([x,y,z,w,h,d]);}
 flush(){const T=THREE;for(let [mat,items] of this.batches){let m=new T.InstancedMesh(this.geo,mat,items.length),o=new T.Object3D();items.forEach((a,i)=>{o.position.set(...a.slice(0,3));o.scale.set(...a.slice(3));o.updateMatrix();m.setMatrixAt(i,o.matrix);});m.castShadow=true;m.receiveShadow=true;this.props.add(m);}this.batches.clear();}
 pine(x,z,s=1){this.tile(x,s*1.1,z,.45*s,2.2*s,.45*s,0x7b5141,'wood');for(let i=0;i<4;i++){let w=(3.6-i*.7)*s,y=(1.3+i*.7)*s;this.tile(x,y,z,w,.72*s,w,0x267a6b,'snow');this.tile(x,y+.4*s,z,w,.15*s,w,0xf5ffff,'snow');}}
 house(x,z,w=5,col=0xc66a50){
 this.tile(x,.25,z,w+.35,.6,4.8,0x657986,'brick');this.tile(x,1.95,z,w,3.2,4.6,col,'wood');
 for(let sign of[-1,1]){this.tile(x+sign*(w/2-.12),1.9,z,.25,3.5,4.7,0x574943,'wood');this.tile(x+sign*(w/2-.12),3.45,z,.35,.14,4.8,0xfff4d7);}
 for(let y of[.7,3.3])this.tile(x,y,z+2.34,w,.18,.18,0x645245,'wood');
 for(let i=0;i<7;i++){let rw=w+1.3-i*(w+.75)/7;this.tile(x,3.6+i*.25,z,rw,.28,5.5,0x204f61,'wood');this.tile(x,3.78+i*.25,z,rw+.05,.1,5.6,0xe9f4f8,'snow');}
 for(let i=-2;i<=2;i++)this.tile(x+i,3.52-(i%2)*.08,z+2.8,.065,.32+(i%2)*.1,.07,0xb8d9e4);
 this.tile(x,1.15,z+2.36,.95,1.95,.13,0x40566a,'wood');this.tile(x-.52,1.18,z+2.4,.12,2.18,.18,0xe9d9b8);this.tile(x+.52,1.18,z+2.4,.12,2.18,.18,0xe9d9b8);this.tile(x,2.24,z+2.4,1.16,.13,.18,0xe9d9b8);this.tile(x+.3,1.03,z+2.5,.09,.11,.07,0xf4c468);
 for(let sign of[-1,1]){let wx=x+sign*1.55;this.tile(wx,2,z+2.36,1.05,1.15,.15,0x1f3949);this.tile(wx,2,z+2.45,.84,.94,.08,0xffc263);for(let y of[1.44,2.55])this.tile(wx,y,z+2.5,1.24,.12,.2,0xf0dfc2);for(let xx of[-.56,0,.56])this.tile(wx+xx,2,z+2.51,.09,1.18,.12,0xf0dfc2);this.tile(wx,2,z+2.53,1.13,.075,.1,0xf0dfc2);this.tile(wx,1.38,z+2.58,1.4,.18,.47,0xd7e8ed,'snow');}
 this.tile(x,.08,z+2.8,1.5,.2,.7,0x9eafba,'brick');this.tile(x,.02,z+3.2,1.8,.1,.5,0xc5d9df);
 this.tile(x+1.3,5.2,z-1.2,.62,1.6,.72,0x866d68,'brick');this.tile(x+1.3,6,z-1.2,.86,.16,.91,0xe3f1f3);
 }

 sign(text,x,y,z,width=6,color='#143d56'){let c=document.createElement('canvas');c.width=512;c.height=128;let cx=c.getContext('2d');cx.fillStyle=color;cx.fillRect(0,0,512,128);cx.fillStyle='#9ee9ed';cx.fillRect(8,8,496,4);cx.fillRect(8,116,496,4);cx.fillStyle='#fff8dd';cx.font='bold 45px monospace';cx.textAlign='center';cx.fillText(text,256,81);let tex=new THREE.CanvasTexture(c);tex.magFilter=THREE.NearestFilter;tex.encoding=THREE.sRGBEncoding;let p=new THREE.Mesh(new THREE.PlaneGeometry(width,width/4),new THREE.MeshBasicMaterial({map:tex}));p.position.set(x,y,z);this.props.add(p);}
 staticWorld(){for(let x=-42;x<=42;x+=3)for(let z=-42;z<=30;z+=3){let play=Math.abs(x)<=9&&Math.abs(z)<=9;this.tile(x,-.45,z,3,.8,3,play?0xdff3f8:(x+z)%6===0?0xd1e5ef:0xe6f4f8,'snow');}for(let side of[-1,1]){for(let n=-10;n<=10;n+=2){this.tile(side*10,.25,n,.35,.7,1.9,0x65b8cb,'wood');this.tile(n,.25,side*10,1.9,.7,.35,0x65b8cb,'wood');}for(let z=-8;z<=8;z+=8){this.tile(side*10,2.1,z,.18,4.2,.18,0x566a82);this.tile(side*10,4.2,z,.6,.55,.6,0xffe79a);this.tile(side*10,4.55,z,.8,.18,.8,0x294d64);}for(let k=0;k<4;k++){this.tile(side*(12+k*.85),k*.5,-1,.95,.45,12,0x9bbdca,'wood');}for(let k=0;k<15;k++){let x=side*(12+Math.floor(k/5)*.85),z=-5+(k%5)*2.2,y=Math.floor(k/5)*.5;this.tile(x,y+.65,z,.55,.7,.4,[0xef7c7c,0xe4b657,0x6e91d3][k%3]);this.tile(x,y+1.2,z,.52,.52,.52,0xf0c3a0);this.tile(x,y+1.49,z,.6,.16,.55,0x284c68);}}for(let z=-8;z<=8;z+=2){this.tile(-8.8,.001,z,.25,.02,.7,0x549fb9);this.tile(8.8,.001,z,.25,.02,.7,0x549fb9);}for(let x=-8;x<=8;x+=2){this.tile(x,.005,-8.8,.7,.02,.25,0x549fb9);this.tile(x,.005,8.8,.7,.02,.25,0x549fb9);}for(let x=-2;x<=2;x++){this.tile(x*.6,.015,0,.55,.02,.55,0xb4dce9);this.tile(0,.015,x*.6,.55,.02,.55,0xb4dce9);}for(let x=-20;x<=20;x+=8)this.house(x,-19,5,x%16===0?0xc46e5f:0x608caa);this.house(-24,-5,6,0x6a9c8e);this.house(24,-5,6,0xc88c5f);for(let i=0;i<40;i++){let a=i*2.399,r=24+(i%5)*3;this.pine(Math.cos(a)*r,Math.sin(a)*r,1+(i%3)*.25);}for(let i=0;i<13;i++){let x=-60+i*10,z=-55-(i%3)*5;for(let k=0;k<5;k++)this.tile(x,k*3-1,z,15-k*2.4,3.1,12-k, k>=3?0xf2f8ff:0x8baac4,'snow');}for(let n=-3;n<=3;n++){this.tile(n*2,5,-12,1.2,.6,.12,n%2?0xff6478:0x30bfd0);this.tile(n*2,4.55,-12,.7,.3,.12,n%2?0xff6478:0x30bfd0);}this.tile(0,5.5,-12,15,.07,.08,0x486c85);this.sign('SNOWBREAK',0,3.6,-11.8,7);this.tile(-5,2,-12,.3,4,.3,0x6b5554,'wood');this.tile(5,2,-12,.3,4,.3,0x6b5554,'wood');}
 details(){
 // Timber boundary, chunky corner stones and flags give the arena a readable edge.
 for(let side of[-1,1])for(let k=-10;k<=10;k+=2){this.tile(side*10,.65,k,.38,.12,1.95,0xf4f6eb);this.tile(k,.65,side*10,1.95,.12,.38,0xf4f6eb);if(k%4===2){this.tile(side*10,.48,k,.55,1,.55,0x365a68,'wood');this.tile(k,.48,side*10,.55,1,.55,0x365a68,'wood');}}
 for(let side of[-1,1]){let x=side*8.5;this.tile(x,1.5,-12,1.2,3,1.2,0x556e7c,'brick');this.tile(x,3.1,-12,1.5,.22,1.5,0xe0edf0);this.tile(x,4.3,-12,.13,2.2,.13,0x574f4b);for(let i=0;i<4;i++)this.tile(x+side*.45,5-i*.2,-12,.75-i*.12,.2,.06,side===1?0xeb785b:0x2696ac);}
 for(let side of[-1,1])for(let z of[-7,0,7]){this.tile(side*11.4,.25,z,1.4,.5,1.5,0x476579,'wood');this.tile(side*11.4,.53,z,1.5,.09,1.6,0xecf7ff);}
 for(let side of[-1,1]){let x=side*7,z=-14;this.tile(x,.7,z,1.2,1.3,1.1,0xeef5f5,'snow');this.tile(x,1.7,z,.85,.85,.85,0xeef5f5,'snow');this.tile(x,2.2,z,.95,.13,.95,0x354459);this.tile(x,2.42,z,.6,.35,.6,0x354459);this.tile(x,1.8,z+.52,.14,.12,.4,0xf18e44);for(let xx of[-.22,.22])this.tile(x+xx,1.97,z+.44,.08,.08,.035,0x263d4e);this.tile(x,1.38,z,1,.12,.95,0xf17f66);for(let y of[.4,.75,1.1])this.tile(x,y,z+.56,.09,.09,.035,0x30475b);}
 for(let i=0;i<12;i++){let x=-11+i*2;this.tile(x,.04,-15,1.8,.07,1.2,0xa8bbc4,'brick');}
 this.smoke=[];for(let i=0;i<10;i++){let m=new THREE.Mesh(this.geo,new THREE.MeshBasicMaterial({color:0xe7f4ff,transparent:true,opacity:.18,depthWrite:false}));this.scene.add(m);this.smoke.push(m);}
 }
 refinedScenery(){
 // Raised stone plinths, timber braces and ridge snow make buildings read as structures.
 for(let x=-20;x<=20;x+=8){for(let side of[-1,1]){this.tile(x+side*2.15,2,-16.58,.12,2.4,.15,0x514638,'wood');this.tile(x+side*1.55,.95,-16.45,1.2,.18,.28,0x465a57,'wood');this.tile(x+side*1.55,1.08,-16.42,1.28,.08,.34,0xe4f1ed,'snow');for(let k=0;k<3;k++)this.tile(x+side*1.55+(k-1)*.25,1.16,-16.38,.2,.15,.18,0x366e5b);}
 for(let zz=-21;zz<=-17;zz+=.8)this.tile(x,5.4,zz,.75,.12,.65,0xeef7f6,'snow');
 this.tile(x,2.4,-16.18,1.2,.12,.65,0x4d6064,'wood');this.tile(x,2.49,-16.18,1.25,.08,.68,0xe8f2f3,'snow');}
 // Decorative stacks remain outside the collision boundary.
 for(let side of[-1,1]){for(let n=0;n<3;n++){this.tile(side*(12.8+n*.7),.25,8,.62,.5,1.1,0x8a6750,'wood');this.tile(side*(12.8+n*.7),.55,8,.67,.1,1.12,0xe8f3f0,'snow');}this.tile(side*12.9,1,8,.7,.4,.95,0x947251,'wood');this.tile(side*12.9,1.23,8,.75,.08,1,0xe5f2f2,'snow');}
 // A cable lift and a timber lookout build depth behind the playable court.
 for(let side of[-1,1]){let x=side*14;this.tile(x,5.3,-27,.55,10.6,.55,0x456675,'wood');this.tile(x,10.6,-27,4,.35,.5,0x355165);for(let k=-1;k<=1;k++)this.tile(x+k*1.2,10.85,-27,.5,.2,.8,0x8aaab4);}
 this.tile(0,11,-27,36,.05,.05,0x334f61);this.tile(0,10.85,-27.6,36,.05,.05,0x334f61);
 this.cabins=[];for(let i=0;i<2;i++){let cab=new THREE.Group();this.box(cab,0,0,0,1.8,1.6,1.4,i?0xd4845f:0x428b94,'wood');this.box(cab,0,.9,0,2.1,.22,1.7,0xe5f2f3,'snow');this.box(cab,0,.28,.73,1.4,.58,.06,0x163e55,'glass');for(let xx of[-.72,0,.72])this.box(cab,xx,.28,.79,.06,.65,.07,0xe8e4c8);this.box(cab,0,1.4,0,.1,.8,.1,0x304958);this.compact(cab);this.scene.add(cab);this.cabins.push(cab);}
 for(let side of[-1,1]){this.pine(side*16,-12,1.15);for(let n=0;n<3;n++){this.tile(side*(17+n*.7),.6+n*.25,-10-n,.8,1.2+n*.5,1.1,0x74aabe,'snow');this.tile(side*(17+n*.7),1.3+n*.5,-10-n,.83,.12,1.13,0xeaf6f7,'snow');}}
 // Warm lantern cores contrast against cold snow without extra shadow lights.
 const T=THREE;let glow=new T.MeshBasicMaterial({color:0xffce83});for(let side of[-1,1])for(let z of[-8,0,8]){let m=new T.Mesh(this.geo,glow);m.position.set(side*10,4.2,z);m.scale.set(.35,.37,.35);this.props.add(m);for(let xx of[-.22,.22])this.tile(side*10+xx,4.2,z,.045,.58,.48,0x345062);this.tile(side*10,4.2,z+.23,.48,.045,.04,0x345062);}
 }
 actor(color,id){
 const T=THREE,g=new T.Group(),body=new T.Group();g.add(body);
 const ink=0x203447,cream=0xf4ead1,skin=[0xe6af86,0xc88a67,0xefc6a2,0xb97556][id],dark=[0x087186,0xa52c43,0x5d478e,0xa66526][id];
 this.box(body,0,1.04,0,.66,.7,.43,color,'fabric');
 this.box(body,0,.75,0,.7,.15,.47,dark,'fabric');
 this.box(body,0,1.35,0,.57,.18,.4,color,'fabric');
 for(let side of[-1,1]){this.box(body,side*.205,.92,.24,.2,.18,.035,dark);this.box(body,side*.205,1.015,.26,.2,.035,.025,cream);this.box(body,side*.22,1.23,.23,.1,.12,.035,cream);}
 this.box(body,0,1.1,.242,.025,.47,.025,ink);this.box(body,.025,1.3,.26,.055,.065,.025,0xe8c36e);
 let scarf=this.box(body,0,1.46,-.01,.71,.16,.51,cream,'fabric');scarf.userData.keep=true;
 const tail=this.box(body,-.19,1.22,.31,.18,.37,.07,cream,'fabric');tail.userData.keep=true;
 for(let yy of[1.09,1.15])this.box(body,-.19,yy,.35,.18,.025,.018,dark);
 // Padded pack, straps and rolled blanket are visible in the chase camera.
 this.box(body,0,1.09,-.34,.48,.56,.26,dark,'fabric');this.box(body,0,1.15,-.49,.38,.35,.06,color);
 for(let side of[-1,1]){this.box(body,side*.19,1.12,-.51,.045,.42,.025,cream);this.box(body,side*.19,1.02,-.535,.08,.08,.025,0xccad66);}
 this.box(body,0,1.46,-.38,.59,.16,.22,cream,'fabric');
 this.box(body,0,1.78,0,.62,.57,.56,skin);
 this.box(body,0,1.53,.02,.47,.1,.47,skin);
 for(let side of[-1,1]){this.box(body,side*.34,1.76,0,.1,.18,.19,skin);this.box(body,side*.235,1.65,.29,.1,.055,.02,0xd68475);}
 this.box(body,0,1.66,.31,.095,.09,.1,skin);this.box(body,0,1.57,.29,.13,.025,.02,0x805247);
 // Layered knitted cap, ribbed brim, pompom and wide framed snow goggles.
 this.box(body,0,2.045,0,.69,.15,.65,dark,'fabric');this.box(body,0,2.17,0,.6,.17,.55,color,'fabric');this.box(body,0,2.28,0,.44,.09,.42,color,'fabric');
 for(let i=-3;i<=3;i++)this.box(body,i*.086,2.04,.333,.025,.13,.02,cream);
 this.box(body,0,2.39,0,.2,.16,.2,cream);this.box(body,0,2.48,0,.12,.06,.12,cream);
 this.box(body,0,1.85,0,.68,.17,.6,ink);
 for(let side of[-1,1]){this.box(body,side*.15,1.86,.32,.27,.21,.085,cream);this.box(body,side*.15,1.86,.37,.21,.145,.035,0x16485c,'glass');this.box(body,side*.15-.045,1.9,.392,.07,.025,.015,0x80dfdf);}
 this.box(body,0,1.86,.36,.065,.07,.08,ink);
 let limbs=[];for(let k=0;k<4;k++){let part=new T.Group(),leg=k<2,side=k%2?1:-1;part.position.set(side*(leg?.19:.46),leg?.68:1.35,0);
 if(leg){this.box(part,0,-.22,0,.27,.46,.32,ink,'fabric');this.box(part,0,-.26,.175,.19,.17,.035,dark);this.box(part,0,-.44,.02,.3,.19,.34,dark);this.box(part,0,-.55,.085,.32,.2,.47,0x304153,'leather');this.box(part,0,-.65,.085,.34,.055,.49,0x152c3c);for(let y of[-.47,-.53])this.box(part,0,y,.325,.21,.025,.02,cream);}
 else{this.box(part,0,-.13,0,.27,.32,.32,color,'fabric');this.box(part,0,-.35,.01,.25,.22,.3,dark,'fabric');this.box(part,0,-.45,.01,.29,.09,.33,cream);this.box(part,0,-.57,.025,.28,.19,.31,dark,'leather');this.box(part,-side*.16,-.55,.05,.09,.12,.14,dark);}
 body.add(part);this.compact(part);limbs.push(part);}
 let ring=new T.Mesh(new T.RingGeometry(.5,.58,32),new T.MeshBasicMaterial({color,side:T.DoubleSide,transparent:true,opacity:.75}));ring.rotation.x=-Math.PI/2;ring.position.y=.035;g.add(ring);
 let held=new T.Mesh(new T.IcosahedronGeometry(.23,1),this.mat(0xf8ffff));held.position.set(0,-.59,.17);limbs[3].add(held);
 // Small seam guards and layered shoulder panels preserve the block silhouette.
 for(let side of[-1,1]){this.box(body,side*.31,1.19,.01,.08,.27,.46,dark,'fabric');this.box(body,side*.29,1.34,.04,.1,.05,.42,cream);this.box(body,side*.255,.8,.25,.035,.11,.02,0xddb65b);}
 this.box(body,0,.73,.27,.12,.075,.025,0xc8a96a);
 this.box(body,0,1.97,-.3,.62,.08,.05,0x4e3c35);for(let side of[-1,1])this.box(body,side*.29,1.91,.16,.055,.13,.2,0x4e3c35);
 let badgeCanvas=document.createElement('canvas');badgeCanvas.width=badgeCanvas.height=32;let bx=badgeCanvas.getContext('2d');bx.fillStyle='#193c50';bx.fillRect(0,0,32,32);bx.fillStyle='#f6e8bb';bx.fillRect(2,2,28,1);bx.font='bold 18px monospace';bx.textAlign='center';bx.fillText('0'+(id+1),16,23);let badgeTex=new T.CanvasTexture(badgeCanvas);badgeTex.magFilter=T.NearestFilter;badgeTex.encoding=T.sRGBEncoding;let patch=new T.Mesh(new T.PlaneGeometry(.27,.27),new T.MeshBasicMaterial({map:badgeTex}));patch.rotation.y=Math.PI;patch.position.set(0,1.16,-.526);patch.userData.keep=true;body.add(patch);
 this.compact(body);g.scale.setScalar(1.16);this.scene.add(g);return{g,body,limbs,ring,scarf,held,tail};
 }
 compact(group){const batches=new Map();for(let c of [...group.children])if(c.isMesh&&!c.userData.keep){if(!batches.has(c.material))batches.set(c.material,[]);batches.get(c.material).push(c);}for(let [mat,parts] of batches){if(parts.length<2)continue;let m=new THREE.InstancedMesh(this.geo,mat,parts.length);parts.forEach((p,i)=>{p.updateMatrix();m.setMatrixAt(i,p.matrix);group.remove(p);});m.castShadow=true;m.receiveShadow=true;group.add(m);}}

 makeFilmProps(){
 const T=THREE;this.filmProps=new T.Group();this.scene.add(this.filmProps);this.filmProps.visible=false;
 this.sled=new T.Group();this.box(this.sled,0,.12,0,1.1,.14,1.6,0xb97749,'wood');for(let x of[-.43,.43]){this.box(this.sled,x,-.02,0,.12,.13,1.85,0x345266);this.box(this.sled,x,.12,.9,.12,.32,.12,0x345266);}this.compact(this.sled);this.filmProps.add(this.sled);
 this.trophy=new T.Group();this.box(this.trophy,0,0,0,.5,.12,.4,0x294d62);this.box(this.trophy,0,.25,0,.12,.45,.12,0xe4b547);this.box(this.trophy,0,.55,0,.48,.33,.32,0xf5cd69);for(let x of[-.31,.31]){this.box(this.trophy,x,.54,0,.12,.28,.16,0xf5cd69);this.box(this.trophy,x*.7,.72,0,.2,.08,.16,0xf5cd69);}this.compact(this.trophy);this.filmProps.add(this.trophy);
 this.podium=new T.Group();this.box(this.podium,0,.2,0,1.65,.4,1.4,0x247f90,'wood');this.box(this.podium,0,.44,0,1.75,.08,1.5,0xeaf5ee,'snow');this.box(this.podium,0,.24,.72,.16,.22,.025,0xf4da87);this.compact(this.podium);this.filmProps.add(this.podium);
 this.gagBall=new T.Mesh(new T.IcosahedronGeometry(.48,1),this.mat(0xf3fcff,'snow'));this.filmProps.add(this.gagBall);
 this.pile=new T.Group();for(let i=0;i<7;i++)this.box(this.pile,(i%3-1)*.45,.13+Math.floor(i/3)*.25,(i%2-.5)*.5,.7,.45,.7,0xe6f4f5,'snow');this.compact(this.pile);this.filmProps.add(this.pile);
 }
 film(c,s){
 const T=THREE,t=c.t,h=this.actors[0],r=this.actors[1],ease=v=>{v=Math.max(0,Math.min(1,v));return v*v*(3-2*v);};this.filmProps.visible=true;for(let o of this.filmProps.children)o.visible=false;this.focus.visible=false;this.gift.visible=false;this.ballMeshes.forEach(m=>m.visible=false);
 const x=c.type==='intro'?s.players[0].x:0,z=c.type==='intro'?s.players[0].z:6;
 h.g.position.set(x,0,z);h.body.rotation.set(0,-.2,0);h.limbs.forEach(l=>l.rotation.set(0,0,0));h.held.visible=false;
 
 if(c.type==='intro'){
 let travel=1-ease(t/1.7);h.g.position.x=x-5*travel;h.g.position.y=.2;h.body.rotation.y=-.3;h.limbs[0].rotation.x=-.7;h.limbs[1].rotation.x=-.7;this.sled.visible=t<2.8;this.sled.position.set(h.g.position.x,0,z);this.sled.rotation.y=-.3;
 if(t>1.7&&t<3){h.body.rotation.z=Math.sin((t-1.7)*8)*.32*(1-(t-1.7)/1.3);h.limbs[2].rotation.z=.9;h.limbs[3].rotation.z=-.9;}
 if(t>2.6){h.g.position.y=Math.sin(ease((t-2.6)/.7)*Math.PI)*.6;h.limbs[0].rotation.x=0;h.limbs[1].rotation.x=0;h.limbs[3].rotation.x=-2.1;}
 this.gagBall.visible=t>1.6&&t<3.8;let u=ease((t-1.6)/1.1);this.gagBall.scale.setScalar(.65);this.gagBall.position.set(x+.2,3.8-u+Math.abs(Math.sin(Math.max(0,t-2.7)*5))*.6,z+.1);
 }else if(c.type==='win'){
 this.podium.visible=true;this.podium.position.set(x,0,z);h.g.position.y=.5+Math.abs(Math.sin(t*4))*.14;h.limbs[2].rotation.x=-2.1;h.limbs[3].rotation.x=-2.1;this.trophy.visible=true;this.trophy.position.set(x,2.45,z+.8);this.trophy.rotation.z=t>2.7?Math.sin(t*12)*.18:0;
 r.g.position.set(x-2,0,z-.3);r.body.rotation.y=.7;r.limbs[3].rotation.x=-1.4;
 this.gagBall.visible=t>2&&t<3.3;let u=ease((t-2)/1.1);this.gagBall.scale.setScalar(.7);this.gagBall.position.set(x-2+u*2,1.8+Math.sin(u*Math.PI)*1.5,z+.1);if(t>3.1&&t<3.18)this.burst({type:'power',x,z});if(t>3.2){h.body.rotation.z=Math.sin(t*10)*.1;h.limbs[3].rotation.x=-1.4;}
 }else{
 let rise=ease((t-2.1)/1.4);this.pile.visible=t<3.7;this.pile.position.set(x,0,z);this.pile.scale.setScalar(1-rise*.6);h.g.position.y=-.9*(1-rise);h.body.rotation.z=.18*(1-rise);h.limbs[3].rotation.x=-1.5;h.limbs[2].rotation.x=rise>.8?-1.3:0;
 r.g.position.set(x-3+ease(t/1.8)*1.9,0,z);r.body.rotation.y=1.2;r.limbs[3].rotation.x=-1.5;r.limbs[3].rotation.z=-.6;
 if(t>3.6){h.body.rotation.y=-1.2;h.limbs[3].rotation.x=-1.5;r.body.rotation.y=1.2;}
 }
 let cx=h.g.position.x;let cp=new T.Vector3(cx+4.1,4.1,z+7.8),ct=new T.Vector3(cx,1.1,z);if(t<.07){this.camera.position.copy(cp);this.camTarget.copy(ct);}else{this.camera.position.lerp(cp,.13);this.camTarget.lerp(ct,.18);}
 }
 load(s){for(let w of this.walls)this.scene.remove(w);this.walls=s.walls.map(w=>{let g=new THREE.Group();for(let y=0;y<2;y++)for(let x=0;x<3;x++)this.box(g,(x-1)*.78,.36+y*.62,0,.76,.6,.75,0xf2fbff,'brick');for(let x=0;x<3;x++)this.box(g,(x-1)*.78,1.31,0,.8,.12,.8,0xf4fbff,'snow');this.compact(g);g.position.set(w.x,0,w.z);this.scene.add(g);return g;});this.level=s.level;let sky=[0xa4dded,0xc4b5ee,0x26455f][s.level];this.scene.background.setHex(sky);this.scene.fog.color.setHex(sky);this.sun.color.setHex([0xffe9cb,0xffcfad,0xa7ddff][s.level]);this.sun.intensity=s.level===2?.95:1.65;}
 burst(e){if(e.type==='hit'||e.type==='break'||e.type==='power'){this.shake=e.type==='hit'?.12:.05;for(let i=0;i<18;i++){let m=new THREE.Mesh(this.fxGeo,this.mat(e.type==='power'||this.starBurst?0xffd35d:i%3?0xffffff:0x69dce4));m.position.set(e.x,.8,e.z);this.scene.add(m);this.fx.push({m,v:new THREE.Vector3((Math.random()-.5)*7,2+Math.random()*5,(Math.random()-.5)*7),life:.5+Math.random()*.4});}}}
 render(s,dt,time,p,cinema=null){this.filmProps.visible=false;if(this.level!==s.level)this.load(s);this.starBurst=p.confetti;let T=THREE,hero=s.players[0];s.players.forEach((a,i)=>{let v=this.actors[i];let moving=v.lastX!==undefined?Math.min(1,Math.hypot(a.x-v.lastX,a.z-v.lastZ)/Math.max(.001,dt)/4):0;v.motion=(v.motion||0)+(moving-(v.motion||0))*(1-Math.exp(-dt*12));v.lastX=a.x;v.lastZ=a.z;v.g.position.set(a.x,Math.abs(Math.sin(a.walk))*.055*v.motion,a.z);v.body.rotation.y=s.phase==='ready'&&i===0?-.35:a.angle;v.body.rotation.z=a.stun?Math.sin(time*30)*.18:0;v.body.position.y=a.stun?.06:Math.sin(time*2.6+i)*.012;v.limbs.forEach((l,j)=>{l.rotation.z=0;let swing=(j%2?1:-1)*Math.sin(a.walk)*.55*v.motion;l.rotation.x+=(swing-l.rotation.x)*(1-Math.exp(-dt*18));});let arm=a.throw>0?-1.45:a.charge>.2?-2.5:-.13;v.limbs[3].rotation.x+=(arm-v.limbs[3].rotation.x)*(1-Math.exp(-dt*(a.throw>0?40:12)));v.tail.rotation.x=Math.sin(time*5+a.walk)*.08*v.motion;if(s.phase==='result'&&i===0){v.body.rotation.y=0;v.g.position.y=.12+Math.abs(Math.sin(time*4))*.18;v.limbs[2].rotation.x=-2.5;v.limbs[3].rotation.x=-2.5;}v.held.visible=a.charge>.1&&s.phase==='play';v.held.scale.setScalar(.7+a.charge*.6);if(i===0)v.scarf.material=this.mat(p.gold?0xffcb39:0xfff5cf);v.ring.scale.setScalar(a.immune>0?1+Math.sin(time*20)*.2:1);});this.walls.forEach((w,i)=>{w.visible=s.walls[i].hp>0;w.scale.y=s.walls[i].hp===1?.55:1;});while(this.ballMeshes.length<s.shots.length){let m=new T.Mesh(new T.IcosahedronGeometry(.23,0),this.mat(0xffffff));m.castShadow=true;this.scene.add(m);this.ballMeshes.push(m);}this.ballMeshes.forEach((m,i)=>{let b=s.shots[i];m.visible=!!b;if(b){m.position.set(b.x,1.1,b.z);m.rotation.x=time*15;m.rotation.z=time*12;m.scale.setScalar(b.strong?1.6:1);}});let q=s.players.filter(a=>a.id).sort((a,b)=>Math.hypot(a.x-hero.x,a.z-hero.z)-Math.hypot(b.x-hero.x,b.z-hero.z))[0];this.focus.position.set(q.x,.05,q.z);this.focus.rotation.z=time*.8;this.focus.visible=s.phase==='play';this.gift.visible=!!s.pickup;if(s.pickup){this.gift.position.set(s.pickup.x,.8+Math.sin(time*3)*.15,s.pickup.z);this.gift.rotation.y=time*1.5;}for(let i=this.fx.length-1;i>=0;i--){let f=this.fx[i];f.life-=dt;f.v.y-=dt*10;f.m.position.addScaledVector(f.v,dt);f.m.rotation.x+=dt*6;f.m.scale.setScalar(Math.max(.1,f.life*1.5));if(f.life<=0){this.scene.remove(f.m);this.fx.splice(i,1);}}for(let i=0;i<100;i++){let x=((i*13.47+time*.5)%40)-20,z=((i*7.13)%38)-20,y=14-((i*.73+time*.8)%14);this.dummy.position.set(x,y,z);this.dummy.scale.setScalar(.045+(i%3)*.018);this.dummy.updateMatrix();this.snow.setMatrixAt(i,this.dummy.matrix);}this.snow.instanceMatrix.needsUpdate=true;this.cabins.forEach((m,i)=>{m.position.set(Math.sin(time*.045+i*Math.PI)*15,9.1,-27.3);m.rotation.z=Math.sin(time*.8+i)*.025;});this.smoke.forEach((m,i)=>{let life=(time*.2+i*.2)%2;m.position.set((i<5?-2.7:5.3)+life*.5,6+life*2,-20.2);m.scale.setScalar(.35+life*.5);m.rotation.y=life*.8;m.material.opacity=.16*(1-life/2);});
let intro=s.phase==='ready',end=s.phase==='result';let desired=new T.Vector3(intro?hero.x+4:hero.x*.65,(intro?5.2:10.5),intro?hero.z+10:hero.z*.48+19);if(!cinema){this.camera.position.lerp(desired,1-Math.exp(-dt*3));this.camTarget.lerp(new T.Vector3(intro?hero.x:hero.x*.65,intro?.4:1,intro?hero.z-1:hero.z*.48-2),1-Math.exp(-dt*4));}if(cinema)this.film(cinema,s);this.shake=Math.max(0,this.shake-dt);this.camera.lookAt(this.camTarget.x+(Math.random()-.5)*this.shake,this.camTarget.y,this.camTarget.z);let w=this.renderer.domElement.clientWidth,h=this.renderer.domElement.clientHeight;if(this.w!==w||this.h!==h){this.w=w;this.h=h;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}this.renderer.render(this.scene,this.camera);}
}
